package com.nuke.getJob.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nuke.getJob.models.SubmittedJobs;

@Repository
public interface SubmittedJobsRepository extends JpaRepository<SubmittedJobs, Integer> {
	public SubmittedJobs findBysEmail(String email);
}
