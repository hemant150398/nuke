package com.nuke.getJob.serivces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nuke.getJob.DAO.SubmittedJobsRepository;
import com.nuke.getJob.models.SubmittedJobs;

@Service
public class SubmittedJobsService {
	@Autowired SubmittedJobsRepository submittedJobsRepository;
	public boolean isExists(String email) {
		if(submittedJobsRepository.findBysEmail(email)==null)
			return false;
		else
			return true;
	}
	public void save(SubmittedJobs submittedJobs) {
		submittedJobsRepository.save(submittedJobs);
	}
}
