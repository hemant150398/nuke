package com.nuke.getJob.controllers;

import java.sql.Date;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nuke.getJob.models.Jobs;
import com.nuke.getJob.serivces.JobsServices;
@Controller
public class JobsController {
Jobs job=new Jobs();
@Autowired JobsServices jobsService;
	@RequestMapping("/jobslogin")
	public String setData(@RequestParam("name") String name,
			@RequestParam("address") String address,
			@RequestParam("salary") String salary,
			@RequestParam("requiredskillset") String requiredSkillSet,
			@RequestParam("experience") String experience,
			@RequestParam("email") String email,
			@RequestParam("date1") Date doi,
			@RequestParam("date") Date date){
		System.out.println("hello........");
		job.setName(name);
		job.setAddress(address);
		job.setSalary(salary);
		job.setRequiredSkillSet(requiredSkillSet);
		job.setExperience(experience);
		job.setEmail(email);
		job.setDoi(doi);
		job.setDate(date);
		System.out.println("hello........");
		jobsService.setJobs(job);
		return "msg";
	}
	@RequestMapping(value="/portal")
	public ModelAndView getData( ) {
		ArrayList<Jobs> jobs= jobsService.getData();
		System.out.println("-------------------"+jobs.get(0).getId());
		ModelAndView mv=new ModelAndView();
		mv.addObject("jobss",jobs);
		mv.setViewName("studentportal");
		System.out.println(jobs.get(0));
		return mv;
	}	
}
