package com.nuke.getJob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetJobApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetJobApplication.class, args);
	}

}
