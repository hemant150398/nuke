package com.nuke.getJob.DAO;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nuke.getJob.models.ApplyJobs;

@Repository
public interface ApplyJobsRepository extends JpaRepository<ApplyJobs, Integer>{
		public ArrayList<ApplyJobs> findByCemail(String cemail);
		public ApplyJobs findBySemail(String semail);
		public void deleteById(Integer id);
}
