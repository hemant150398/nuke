package com.nuke.getJob.DAO;

import java.util.ArrayList;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nuke.getJob.models.ApplyJobs;
import com.nuke.getJob.models.Company;
import com.nuke.getJob.models.Jobs;

@Repository
public interface JobsRepository extends JpaRepository<Jobs, Integer> {
	 public ArrayList<Jobs>  findAll();
	 ArrayList<Jobs> findById(int id);
	 public Jobs findByEmail(String email);
	
}
