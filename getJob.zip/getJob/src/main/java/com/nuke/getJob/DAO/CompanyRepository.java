package com.nuke.getJob.DAO;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nuke.getJob.models.Company;

@Repository
public interface CompanyRepository extends JpaRepository<Company, Integer> {
	Company findByEmail(String email);
	
}
