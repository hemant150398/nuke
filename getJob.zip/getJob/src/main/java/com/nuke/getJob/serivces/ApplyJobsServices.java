package com.nuke.getJob.serivces;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nuke.getJob.DAO.ApplyJobsRepository;
import com.nuke.getJob.models.ApplyJobs;

@Service
public class ApplyJobsServices {
	@Autowired ApplyJobsRepository applyJobsRepository;
	public void save(ApplyJobs applyJobs) {
		applyJobsRepository.save(applyJobs);
	}
	public ArrayList<ApplyJobs> getInfo(String cemail) {
		ArrayList<ApplyJobs> list=applyJobsRepository.findByCemail(cemail);
		return list;
	}
	public boolean isExsists(String email) {
		if(applyJobsRepository.findBySemail(email)==null)
			return false;
		else
			return true;
	}
	public String findEmail(String email) {
		String companyEmail=applyJobsRepository.findBySemail(email).getCemail();
		return companyEmail;
	}
	public void deleteRec(String email) {
		int id=applyJobsRepository.findBySemail(email).getId();
		applyJobsRepository.deleteById(id);
	}
	
}
