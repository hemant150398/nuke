package com.nuke.getJob.serivces;


import java.util.ArrayList;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.nuke.getJob.DAO.CompanyRepository;
import com.nuke.getJob.models.Company;

@Service
public class CompanyService {
	@Autowired
	private JavaMailSender sender;
	@Autowired CompanyRepository companyRepository;
	public void save(Company company) {
		int num= (int) (100*Math.random());
		String newPass="setjob@"+num;
		company.setPassword(newPass);
		
		MimeMessage message = sender.createMimeMessage();
		
        MimeMessageHelper helper = new MimeMessageHelper(message);
        	
        try {
            helper.setTo(company.getEmail());
            helper.setText("Greetings :)"+"\n"+"your password for login is-"+newPass);
            helper.setSubject("hello "+company.getName());
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        sender.send(message);

	 companyRepository.save(company);
	}
	public boolean getData(String email,String password) {
		boolean flag=false;
		Company company=companyRepository.findByEmail(email);
		System.out.println(company);
		if(company.getEmail().equals(email) && company.getPassword().equals(password))
			flag=true;
		return flag;
	}
	public Company getinfo(String email) {
		Company list=companyRepository.findByEmail(email);
		return list;
	}
	public boolean isExists(String email) {
		if(companyRepository.findByEmail(email)==null)
			return false;
		else 
			return true;
	}
	
}
