package com.nuke.getJob.serivces;

import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.nuke.getJob.DAO.JobsRepository;
import com.nuke.getJob.models.Company;
import com.nuke.getJob.models.Jobs;

@Service
public class JobsServices {
	@Autowired JavaMailSender sender;
	@Autowired JobsRepository jobsRepository;
	public void setJobs(Jobs job) {
		jobsRepository.save(job);
	}
	public ArrayList<Jobs> getData() {
		ArrayList<Jobs> jobs=jobsRepository.findAll();
		return jobs;
	}
	public ArrayList<Jobs> getName(int id){
		ArrayList<Jobs> companyList=jobsRepository.findById(id);
		System.out.println("helloooo...."+companyList.get(0).getId());
		return companyList;
	}
	public void sendEmail(String sEmail, String cEmail) {
		Jobs job=jobsRepository.findByEmail(cEmail);
		MimeMessage message = sender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message);
        try {
            helper.setTo(sEmail);
            helper.setText(" you are been slected for the interview in "+job.getName()+"\n"+"your interview date is-"+job.getDoi());
            helper.setSubject("congratulation");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        sender.send(message);
	}
	
}
