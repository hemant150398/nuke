package com.nuke.getJob.controllers;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.nuke.getJob.models.ApplyJobs;
import com.nuke.getJob.models.Company;
import com.nuke.getJob.models.Student;
import com.nuke.getJob.serivces.ApplyJobsServices;
import com.nuke.getJob.serivces.CompanyService;
import com.nuke.getJob.serivces.StudentService;
@Controller
public class CompanyController {
	Company company=new Company();
	String cemail;
	@Autowired CompanyService companyService;
	@Autowired ApplyJobsServices applyJobsServices;
	@Autowired StudentService studentService;
	@RequestMapping("/storecompany")
	@ResponseBody
	public boolean setData(@RequestParam("name") String name,
			@RequestParam("phone") String phone,
			@RequestParam("address") String address,
			@RequestParam("email") String email){
		boolean flag=false;
		if(companyService.isExists(email))
		{
			flag=true;
		}
		else {
		company.setName(name);
		company.setPhone(phone);
		company.setAddress(address);
		company.setEmail(email);
		System.out.println("successss   .....");
		companyService.save(company);
		flag=false;
		}
		System.out.println(flag);
		return flag;
	}
	@RequestMapping(value="/clogin")
	public String studentLogin(@RequestParam("email") String email,@RequestParam("password") String password,HttpServletRequest req) {
		HttpSession session=req.getSession();
		session.setAttribute("email", email);
		String data=null;
		boolean flag=companyService.getData(email,password);

		System.out.println(flag);
		if(flag==true)
			data= "jobportal";
		else
			data= "error";
		return data;
	}
	//fetching the student information on the company portal
	@RequestMapping(value="/search")
	public ModelAndView search(HttpServletRequest req) {
		ModelAndView mv=new ModelAndView();
		try {
			ArrayList<Student> studentList=new ArrayList<>();
			String email=(String)req.getSession().getAttribute("email");
			ArrayList<ApplyJobs> applyJobsList=applyJobsServices.getInfo(email);
			System.out.println("search......."+applyJobsList.get(0).getCemail());
			for(ApplyJobs job:applyJobsList) {
				studentList.add(studentService.getInfo(job.getSemail()));
			}
			mv.addObject("jobss",studentList);
			mv.setViewName("companyPortal");
			System.out.println("helloooo......");
		
		}
		catch(Exception e) {
			mv.setViewName("view");
		}
		return mv;
	}	
}
