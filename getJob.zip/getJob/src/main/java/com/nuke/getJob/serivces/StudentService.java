package com.nuke.getJob.serivces;

import java.util.ArrayList;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.hibernate.criterion.Example;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.nuke.getJob.DAO.ApplyJobsRepository;
import com.nuke.getJob.DAO.StudentRepository;
import com.nuke.getJob.models.ApplyJobs;
import com.nuke.getJob.models.Student;
@Service
public class StudentService {
	@Autowired StudentRepository studentRepository;
	@Autowired
	private JavaMailSender sender;
	@Autowired ApplyJobsRepository applyJobsRepository;
	 ApplyJobs applyJobs; 
	public boolean save(Student student)
	{	
		int num= (int) (100*Math.random());
		String newPass="getjob@"+num;
		student.setPassword(newPass);
		MimeMessage message = sender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message);
        try {
            helper.setTo(student.getEmail());
            helper.setText("Greetings :)"+"\n"+"your password for login is-"+newPass);
            helper.setSubject("hello "+student.getName());
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        sender.send(message);
		studentRepository.save(student);
		//***********sending a mail to user for its email and password**********/
		return true;
	}
	public boolean getData(String email,String password) {
		boolean flag=false;
		Student student=studentRepository.findByEmail(email);
		
		if(student.getEmail().equals(email) && student.getPassword().equals(password)) {	
			flag=true;
		}
		return flag;
	}
	public Student getInfo(String email) {
		Student studentList=studentRepository.findByEmail(email);
		System.out.println(studentList.getName());
		return studentList;
	}
	public void apply(String sname, String semail,String cname) {
		applyJobs.setCname(cname);
		applyJobs.setSname(sname);
		applyJobs.setSemail(semail);
	}
	public boolean existEmail(String email)
	{
		//Example em=new Example(email);
		
		Student student=studentRepository.findByEmail(email);
		System.out.println("helooooo.......");
		if(student==null)
			return false;
		else
			return true;
	}
	public String selectStu(int id) {
		Student student=studentRepository.findById(id);
		return student.getEmail();
	}
}