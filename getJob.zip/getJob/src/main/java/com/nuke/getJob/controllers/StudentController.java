package com.nuke.getJob.controllers;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nuke.getJob.models.ApplyJobs;
import com.nuke.getJob.models.Jobs;
import com.nuke.getJob.models.Student;
import com.nuke.getJob.models.SubmittedJobs;
import com.nuke.getJob.serivces.ApplyJobsServices;
import com.nuke.getJob.serivces.CompanyService;
import com.nuke.getJob.serivces.JobsServices;
import com.nuke.getJob.serivces.StudentService;
import com.nuke.getJob.serivces.SubmittedJobsService;
@Controller
public class StudentController {
	Student student=new Student();
	String sname=student.getName();
	String semail=student.getEmail();
	
	ApplyJobs applyJobs=new ApplyJobs();
	@Autowired StudentService studentService;
	@Autowired JobsServices jobsServices;
	@Autowired CompanyService companyService;
	@Autowired ApplyJobsServices applyJobsServices;
	@Autowired SubmittedJobsService submittedJobsService;
	SubmittedJobs submittedJobs=new SubmittedJobs();
	@RequestMapping(value="/")
	public String index() {
		return  "index";
	}
	@RequestMapping(value="/store")
	@ResponseBody
	public boolean data(@RequestParam("name") String name,
			@RequestParam("qualification") String qualification,
			@RequestParam("phone") String phone,
			@RequestParam("specification") String specification,
			@RequestParam("email") String email) {
		boolean flag= false;
		if(studentService.existEmail(email)==true) {
		
			flag=true;
			}
		else {
		student.setName(name);
		student.setEmail(email);
		student.setQualification(qualification);
		student.setPhone(phone);
		student.setSpecification(specification);
		studentService.save(student);
		System.out.println("task completed");
		flag=false;
		}
		return flag;
	}
	@RequestMapping(value="/login")
	public String studentLogin(@RequestParam("email") String email,@RequestParam("password") String password,HttpServletRequest req) {
		HttpSession session =req.getSession();
		String page=null;
		
		session.setAttribute("email", email);
		boolean flag=studentService.getData(email,password);
		System.out.println(flag);
		if(flag==true)
		page="studentDashboard";
		else
		page="errrorrr";
		return page;
	}
	@RequestMapping(value="/apply")
	@ResponseBody
	public boolean apply(@RequestParam("submit") int id,HttpServletRequest req) {
	
		HttpSession session=req.getSession();
		String email=(String)session.getAttribute("email");
		
		if(applyJobsServices.isExsists(email)==true) {
			return true;
		}
		else {
			ArrayList<Jobs> list=jobsServices.getName(id);
			Student slist=studentService.getInfo(email);
			String cname=list.get(0).getName();
			String cemail=list.get(0).getEmail();
			applyJobs.setCemail(cemail);
			applyJobs.setCname(cname);
			applyJobs.setSemail(slist.getEmail());
			applyJobs.setSname(slist.getName());
			applyJobsServices.save(applyJobs);
			return false;
		}
	}
	@RequestMapping("/select")
	@ResponseBody
	public boolean select(@RequestParam("select") int id) {
		boolean flag=false;
		String sEmail=studentService.selectStu(id);
		String cEmail=applyJobsServices.findEmail(sEmail);
		if(submittedJobsService.isExists(sEmail)) {
			System.out.println("select.......");
			return true;
			}
		else {
			submittedJobs.setcEmail(cEmail);
			submittedJobs.setsEmail(sEmail);
			System.out.println(sEmail+" "+cEmail);
			submittedJobsService.save(submittedJobs);
			jobsServices.sendEmail(sEmail,cEmail);
		
			return false;
		}
	}
	@RequestMapping("/delete")
	@ResponseBody
	public void delete(@RequestParam("select") int id) {
		String email= studentService.selectStu(id);
		applyJobsServices.deleteRec(email);
	}
	
}
